/*
 * Copyright (C) 2018 Microchip Technology Inc.  All rights reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 */
#ifndef __PROGRESS_H__
#define __PROGRESS_H__

#include <egt/ui>
#include <iostream>


static std::pair<egt::EasingFunc, const char*> easing_functions[] =
{
    {egt::easing_linear, "linear"},
    {egt::easing_easy, "easy"},
    {egt::easing_easy_slow, "easy slow"},
    {egt::easing_extend, "extend"},
    {egt::easing_drop, "drop"},
    {egt::easing_drop_slow, "drop slow"},
    {egt::easing_snap, "snap"},
    {egt::easing_bounce, "bounce"},
    {egt::easing_bouncy, "bouncy"},
    {egt::easing_rubber, "rubber"},
    {egt::easing_spring, "spring"},
    {egt::easing_boing, "boing"},
    {egt::easing_quadratic_easein, "quadratic easein"},
    {egt::easing_quadratic_easeout, "quadratic easeout"},
    {egt::easing_quadratic_easeinout, "quadratic easeinout"},
    {egt::easing_cubic_easein, "cubic easein"},
    {egt::easing_cubic_easeout, "cubic easeout"},
    {egt::easing_cubic_easeinout, "cubic easeinout"},
    {egt::easing_quartic_easein, "quartic easein"},
    {egt::easing_quartic_easeout, "quartic easeout"},
    {egt::easing_quartic_easeinout, "quartic easeinout"},
    {egt::easing_quintic_easein, "quintic easein"},
    {egt::easing_quintic_easeout, "quintic easeout"},
    {egt::easing_quintic_easeinout, "quintic easeinout"},
    {egt::easing_sine_easein, "sine easein"},
    {egt::easing_sine_easeout, "sine easeout"},
    {egt::easing_sine_easeinout, "sine easeinout"},
    {egt::easing_circular_easein, "circular easein"},
    {egt::easing_circular_easeout, "circular easeout"},
    {egt::easing_circular_easeinout, "circular easeinout"},
    {egt::easing_exponential_easein, "exponential easein"},
    {egt::easing_exponential_easeout, "exponential easeout"},
    {egt::easing_exponential_easeinout, "exponential easeinout"}
};


template<class T>
static std::shared_ptr<egt::PropertyAnimator> demo_up_animator(std::shared_ptr<T> widget)
{
    auto animation =
        std::make_shared<egt::PropertyAnimator>(0, 100,
                std::chrono::seconds(3),
                egt::easing_easy);
    animation->on_change([widget](egt::PropertyAnimator::Value value)
    {
        widget->value(value);
    });

    return animation;
}

class Progress : public egt::Frame
{
public:
    Progress(egt::Frame& parent) noexcept
        : egt::Frame(parent.box())
    {
        parent.add(*this);
        
        auto round = std::make_shared<egt::experimental::Radial>();
        auto range0 = std::make_shared<egt::RangeValue<int>>(0, 100, 100);
        round->add(range0, egt::Palette::transparent, 10);
        auto range1 = std::make_shared<egt::RangeValue<int>>(0, 100, 0);
        round->add(range1, egt::Palette::yellow, 8, egt::experimental::Radial::RadialFlag::rounded_cap);
        round->readonly(true);
        add(egt::expand(round));

        m_animator = demo_up_animator(range1);
        m_seq = std::make_unique<egt::AnimationSequence>(true);
        m_seq->add(m_animator);

    }
    
    void StartProgress()
    {
        m_seq->start(); 
    }

    void StopProgress(void)
    {
        m_seq->stop(); 
    }

    void ChangeEasing(void)
    {
        static int idx = 0;
        m_seq->stop();
        m_animator->easing_func(easing_functions[idx].first);
        std::cout << "easing: " << easing_functions[idx].second << std::endl;
        m_seq->start();
        idx = idx >= 32 ? 0 : idx + 1;
    }

private:
    std::unique_ptr<egt::AnimationSequence> m_seq;
    std::shared_ptr<egt::PropertyAnimator> m_animator;
};

#if 0
class ProgressSVG : public egt::experimental::SVGDeserial
{
public:
    ProgressSVG(Frame& parent) noexcept
        : egt::experimental::SVGDeserial(parent)
    {
        load();
    }

    std::shared_ptr<egt::experimental::NeedleLayer> ProgressSVG_Get(void)
    {
        return m_rotate;
    }

private:
    void load();
    std::shared_ptr<egt::experimental::NeedleLayer> m_rotate;
};

class ProgressPage : public egt::Frame
{
public:
    ProgressPage(egt::Frame& parent) noexcept
        : egt::Frame(parent.box()),
          m_progressSVG(*this)
    {   
        parent.add(*this);
        m_animator = demo_up_animator(m_progressSVG.ProgressSVG_Get());
    }

    void StartProgress(void)
    {
        m_animator->start(); 
    }

    void StopProgress(void)
    {
        m_animator->stop(); 
    }

private:
    ProgressSVG m_progressSVG;
    std::unique_ptr<egt::AnimationSequence> m_animator;
};
#endif

#endif