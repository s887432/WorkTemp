/*
 * Copyright (C) 2018 Microchip Technology Inc.  All rights reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 */
#if 0
#include <filesystem>
#include <fstream>
#include <memory>
#include <string>
#include <vector>
#include "progress.h"
#include "round_eraw.h"


#define ERAW_NAME "../data/round_eraw.bin"

static size_t getFileSize(const char* fileName) 
{
    if (fileName == NULL)
        return 0;

    struct stat statbuf;
    stat(fileName, &statbuf);
    return statbuf.st_size;
}

void ProgressSVG::load(void)
{
    size_t buff_size = getFileSize(ERAW_NAME);
    void* buff_ptr = NULL;
    if (buff_size) 
    {
        buff_ptr = malloc(buff_size);
    } 
    else 
    {
        std::cerr << ERAW_NAME << " is blank!" << std::endl;
        return;
    }

    std::ifstream f(ERAW_NAME, std::ios::binary);
    if(!f)
    {
        std::cerr << "read " << ERAW_NAME << " failed!" << std::endl;
        free(buff_ptr);
        return;
    }
    
    f.read((char*)buff_ptr, buff_size);

    m_rotate = AddRotateWidgetByBuf((const unsigned char*)buff_ptr+roundprogress::offset_table[0].offset, roundprogress::offset_table[0].len, 
                                    0, 100,
                                    0, 360,
                                    true, egt::Point(50, 50));

    for (auto x = 1; x < sizeof(roundprogress::offset_table)/sizeof(roundprogress::eraw_st); x++)
    {
        auto Obj = AddWidgetByBuf((const unsigned char*)buff_ptr+roundprogress::offset_table[x].offset, roundprogress::offset_table[x].len, false);
        //m_ClusterSVGWgt.push_back(Obj);
    }

    free(buff_ptr);

}
#endif