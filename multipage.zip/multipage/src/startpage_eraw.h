#include <string>	
	
namespace startpage {	
	
typedef struct {	
    std::string name;	
    int offset;	
    int len;	
} eraw_st;	
	
eraw_st offset_table[] = {	
    {"background", 0, 873626},    //0	
    {"text1", 873626, 29542},    //1	
    {"text2", 903168, 6590},    //2	
};	
}	
