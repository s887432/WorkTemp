#include <string>	
	
namespace telephonypage {	
	
typedef struct {	
    std::string name;	
    int offset;	
    int len;	
} eraw_st;	
	
eraw_st offset_table[] = {	
    {"g3", 0, 39810},    //0	
    {"telephonyContainer", 39810, 40434},    //1	
    {"telephoneNumber", 80244, 4548},    //2	
    {"contactName", 84792, 1268},    //3	
};	
}	
