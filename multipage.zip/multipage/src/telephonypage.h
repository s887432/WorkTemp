/*
 * Copyright (C) 2018 Microchip Technology Inc.  All rights reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 */
#ifndef __TELEPHONYPAGE_H__
#define __TELEPHONYPAGE_H__

#include <egt/ui>
#include <iostream>


class TelephonySVG : public egt::experimental::SVGDeserial
{
public:
    TelephonySVG(Frame& parent) noexcept
        : egt::experimental::SVGDeserial(parent)
    {
        load();
    }
    long unsigned int TelephonySVG_GetWgtNums(void)
    {
        return m_TelephonySVGWgt.size();
    }
    std::shared_ptr<egt::experimental::GaugeLayer> TelephonySVG_GetWgt(long unsigned int idx)
    {
        assert(idx < m_TelephonySVGWgt.size());
        return m_TelephonySVGWgt[idx];
    }
    TelephonySVG* TelephonySVG_GetSelf(void)
    {
        return this;
    }

private:
    void load();
    std::vector<std::shared_ptr<egt::experimental::GaugeLayer>> m_TelephonySVGWgt;
};

class TelephonyPage : public egt::Frame
{
public:
    TelephonyPage(egt::Rect box) noexcept
        : egt::Frame(box),
          m_telephonySVG(*this)
    {
        auto pageLabel = std::make_shared<egt::Label>("Telephony page");
        pageLabel->font(egt::Font(20));
        pageLabel->align(egt::AlignFlag::bottom | egt::AlignFlag::left);
        add(pageLabel);
    }

    long unsigned int TelephonyPage_GetWgtNums(void)
    {
        return m_telephonySVG.TelephonySVG_GetWgtNums();
    }

    std::shared_ptr<egt::experimental::GaugeLayer> TelephonyPage_GetWgt(long unsigned int idx)
    {
        assert(idx < m_telephonySVG.TelephonySVG_GetWgtNums());
        return m_telephonySVG.TelephonySVG_GetWgt(idx);
    }

private:
    TelephonySVG m_telephonySVG;
};

#endif