/*
 * Copyright (C) 2018 Microchip Technology Inc.  All rights reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include "startpage.h"
#include "clusterpage.h"
#include "telephonypage.h"
#include "progress.h"


int main(int argc, char** argv)
{
    egt::Application app(argc, argv);
    egt::TopWindow window;
    window.color(egt::Palette::ColorId::bg, egt::Palette::gray);

    //-------Start Window--------//
    auto pStartPageSVG = std::make_shared<StartPage>(window);

    std::shared_ptr<ClusterPage> pClusterPage;
    std::shared_ptr<TelephonyPage> pTelephonyPage;

    auto createNonStartPages = [&window, &pClusterPage, &pTelephonyPage]() {
        //-------Cluster Windows--------//
        pClusterPage = std::make_shared<ClusterPage>(egt::Rect(100, 50, 600, 380));
        window.add(pClusterPage);

        // Show cluster page
        pClusterPage->show();

        // Create telephony page
        // 7 is telephonyContainer rectangle
        pTelephonyPage = std::make_shared<TelephonyPage>(egt::Rect(360, 230, 200, 50));
        window.add(pTelephonyPage);

        // Hide telephony page SVGs
        pTelephonyPage->hide();
    };

    createNonStartPages();

    bool show_telephony_page = false;
    egt::PeriodicTimer timer(std::chrono::milliseconds(500));
    timer.on_timeout([&]()
    {
        std::cout << "timer coming..." << std::endl;
    });
    //timer.start();

    egt::Frame frm(egt::Size(60, 60));
    window.add(center(frm));
    //ProgressPage prog(frm);
    Progress prog(frm);

    prog.StartProgress();

    egt::Button btnchange("switch page");
    window.add(right(btnchange));

    btnchange.on_click([&](egt::Event&) {
        if (show_telephony_page)
        {
            std::cout << "show Telephony" << std::endl;
            pClusterPage->hide();
            pTelephonyPage->show();
            show_telephony_page = false;
        }
        else
        {
            std::cout << "show Cluster" << std::endl;
            pTelephonyPage->hide();
            pClusterPage->show();
            show_telephony_page = true;
        }
    });

    egt::Button btnstart("start");
    window.add(left(btnstart));
    btnstart.on_click([&prog, &frm](egt::Event&) {
        frm.show();
        prog.StartProgress();
    });

    egt::Button btnstop("stop");
    window.add(bottom(btnstop));
    btnstop.on_click([&prog, &frm](egt::Event&) {
        prog.StopProgress();
        frm.hide();
    });

    auto notifyLabel = std::make_shared<egt::Label>("System is initializing, please wait...");
    notifyLabel->fill_flags(egt::Theme::FillFlag::blend);
    notifyLabel->width(400);
    notifyLabel->height(100);
    notifyLabel->font(egt::Font(36));
    notifyLabel->border(3);
    notifyLabel->border_radius(10);
    notifyLabel->color(egt::Palette::ColorId::label_text, egt::Palette::darkblue);
    notifyLabel->color(egt::Palette::ColorId::label_bg, egt::Color(0x167fff64));
    notifyLabel->color(egt::Palette::ColorId::border, egt::Color(0x1521ed80));
    window.add(center(notifyLabel));
    window.show();

    return app.run();
}