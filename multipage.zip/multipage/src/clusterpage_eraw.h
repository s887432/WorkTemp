#include <string>	
	
namespace clusterpage {	
	
typedef struct {	
    std::string name;	
    int offset;	
    int len;	
} eraw_st;	
	
eraw_st offset_table[] = {	
    {"clusterContainer", 0, 4594},    //0	
    {"path1", 4594, 193578},    //1	
    {"speed", 198172, 4964},    //2	
    {"text3", 203136, 3026},    //3	
    {"rect3", 206162, 4536},    //4	
    {"rect4", 210698, 4410},    //5	
    {"path2", 215108, 844},    //6	
    {"path2-8", 215952, 834},    //7	
};	
}	
