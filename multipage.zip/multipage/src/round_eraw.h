#include <string>	
	
namespace roundprogress {	
	
typedef struct {	
    std::string name;	
    int offset;	
    int len;	
} eraw_st;	
	
eraw_st offset_table[] = {	
    {"round", 0, 12926},    //0	
    {"path1", 12926, 12600},    //1	
    {"path2", 25526, 734},    //2	
};	
}	
