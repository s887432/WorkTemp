/*
 * Copyright (C) 2018 Microchip Technology Inc.  All rights reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include <filesystem>
#include <fstream>
#include <memory>
#include <string>
#include <vector>
#include "startpage.h"
#include "startpage_eraw.h"


#define ERAW_NAME "../data/startpage_eraw.bin"

static size_t getFileSize(const char* fileName) 
{
    if (fileName == NULL)
        return 0;

    struct stat statbuf;
    stat(fileName, &statbuf);
    return statbuf.st_size;
}

void StartPage::load(void)
{
    size_t buff_size = getFileSize(ERAW_NAME);
    void* buff_ptr = NULL;
    if (buff_size) 
    {
        buff_ptr = malloc(buff_size);
    } 
    else 
    {
        std::cerr << ERAW_NAME << " is blank!" << std::endl;
        return;
    }

    std::ifstream f(ERAW_NAME, std::ios::binary);
    if(!f)
    {
        std::cerr << "read " << ERAW_NAME << " failed!" << std::endl;
        free(buff_ptr);
        return;
    }
    
    f.read((char*)buff_ptr, buff_size);

    for (auto x = 0; x < sizeof(startpage::offset_table)/sizeof(startpage::eraw_st); x++)
    {
        auto Obj = AddWidgetByBuf((const unsigned char*)buff_ptr+startpage::offset_table[x].offset, startpage::offset_table[x].len, true);
        m_StartPageWgt.push_back(Obj);
    }

    free(buff_ptr);
}