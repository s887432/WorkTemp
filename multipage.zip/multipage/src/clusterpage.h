/*
 * Copyright (C) 2018 Microchip Technology Inc.  All rights reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 */
#ifndef __CLUSTERPAGE_H__
#define __CLUSTERPAGE_H__

#include <egt/ui>
#include <iostream>


class ClusterSVG : public egt::experimental::SVGDeserial
{
public:
    ClusterSVG(Frame& parent) noexcept
        : egt::experimental::SVGDeserial(parent)
    {
        load();
    }
    long unsigned int ClusterSVG_GetWgtNums(void)
    {
        return m_ClusterSVGWgt.size();
    }
    std::shared_ptr<egt::experimental::GaugeLayer> ClusterSVG_GetWgt(long unsigned int idx)
    {
        assert(idx < m_ClusterSVGWgt.size());
        return m_ClusterSVGWgt[idx];
    }
    ClusterSVG* ClusterSVG_GetSelf(void)
    {
        return this;
    }

private:
    void load();
    std::vector<std::shared_ptr<egt::experimental::GaugeLayer>> m_ClusterSVGWgt;
};

class ClusterPage : public egt::Frame
{
public:
    ClusterPage(egt::Rect box) noexcept
        : egt::Frame(box),
          m_clusterSVG(*this)
    {   
        auto pageLabel = std::make_shared<egt::Label>("Cluster page");
        pageLabel->font(egt::Font(60));
        pageLabel->color(egt::Palette::ColorId::label_text, egt::Palette::white);
        pageLabel->align(egt::AlignFlag::top | egt::AlignFlag::left);
        add(pageLabel);
    }

    long unsigned int ClusterPage_GetWgtNums(void)
    {
        return m_clusterSVG.ClusterSVG_GetWgtNums();
    }

    std::shared_ptr<egt::experimental::GaugeLayer> ClusterPage_GetWgt(long unsigned int idx)
    {
        assert(idx < m_clusterSVG.ClusterSVG_GetWgtNums());
        return m_clusterSVG.ClusterSVG_GetWgt(idx);
    }

private:
    ClusterSVG m_clusterSVG;
};

#endif