/*
 * Copyright (C) 2018 Microchip Technology Inc.  All rights reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 */
#ifndef __STARTPAGE_H__
#define __STARTPAGE_H__

#include <egt/ui>
#include <iostream>


class StartPage : public egt::experimental::SVGDeserial
{
public:
    StartPage(Frame& parent) noexcept
        : egt::experimental::SVGDeserial(parent)
    {
        load();
    }
    long unsigned int StartPage_GetWgtNums(void)
    {
        return m_StartPageWgt.size();
    }
    std::shared_ptr<egt::experimental::GaugeLayer> StartPage_GetWgt(long unsigned int idx)
    {
        assert(idx < m_StartPageWgt.size());
        return m_StartPageWgt[idx];
    }
    StartPage* StartPage_GetSelf(void)
    {
        return this;
    }

private:
    void load();
    std::vector<std::shared_ptr<egt::experimental::GaugeLayer>> m_StartPageWgt;
};

#endif