/* ***************************************************************************
 * ©2019 Microchip Technology Inc. and its subsidiaries.
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip   products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.
 * TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
 * CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES,
 * IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 */

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>   /* File Control Definitions           */
#include <termios.h> /* POSIX Terminal Control Definitions */
#include <unistd.h>  /* UNIX Standard Definitions 	   */ 
#include <errno.h>   /* ERROR Number Definitions           */

/*-------------------------------------------------------------*/
/* termios structure -  /usr/include/asm-generic/termbits.h    */ 
/* use "man termios" to get more info about  termios structure */
/*-------------------------------------------------------------*/

int fd;/*File Descriptor*/

bool Open_UART(uint8_t  filepath[])
{


/*------------------------------- Opening the Serial Port -------------------------------*/

/* Change /dev/ttyUSB0 to the one corresponding to your system */

    fd = open(filepath, O_RDWR | O_NOCTTY | O_DSYNC);	/* ttyUSB0 is the FT232 based USB2SERIAL Converter   */
		   						/* O_RDWR Read/Write access to serial port           */
								/* O_NOCTTY - No terminal will control the process   */
								/* O_NDELAY -Non Blocking Mode,Does not care about-  */
								/* -the status of DCD line,Open() returns immediatly */
									
    if (fd == -1)						/* Error Checking */
    {
        printf("\n  Error! in Opening %s\r\n", filepath);
        return false;
    }
    else
        printf("\n  %s Opened Successfully\r\n", filepath);

	
   /*---------- Setting the Attributes of the serial port using termios structure --------- */

    struct termios SerialPortSettings;	/* Create the structure                          */

    tcgetattr (fd, &SerialPortSettings);	/* Get the current attributes of the Serial port */

    cfsetispeed(&SerialPortSettings,B19200); /* Set Read  Speed as 19200                       */
    cfsetospeed(&SerialPortSettings,B19200); /* Set Write Speed as 19200                       */

    SerialPortSettings.c_cflag &= ~PARENB;   /* Disables the Parity Enable bit(PARENB),So No Parity   */
    SerialPortSettings.c_cflag &= ~CSTOPB;   /* CSTOPB = 2 Stop bits,here it is cleared so 1 Stop bit */
    SerialPortSettings.c_cflag &= ~CSIZE;    /* Clears the mask for setting the data size             */
    SerialPortSettings.c_cflag |=  CS8;      /* Set the data bits = 8                                 */
	
    SerialPortSettings.c_cflag &= ~CRTSCTS;       /* No Hardware flow Control                         */
    SerialPortSettings.c_cflag |= CREAD | CLOCAL; /* Enable receiver,Ignore Modem Control lines       */ 
		
		
    SerialPortSettings.c_iflag &= ~(IXON | IXOFF | IXANY);          /* Disable XON/XOFF flow control both i/p and o/p */
    SerialPortSettings.c_iflag &= ~(ICANON | ECHO | ECHOE | ISIG);  /* Non Cannonical mode                            */

    SerialPortSettings.c_oflag &= ~OPOST;/*No Output Processing*/

    SerialPortSettings.c_cc[VMIN] = 30;
    SerialPortSettings.c_cc[VTIME] = 100;


    if ((tcsetattr(fd,TCSANOW,&SerialPortSettings)) != 0) /* Set the attributes to the termios structure*/
        printf("\n  ERROR ! in Setting attributes");
    else
        printf("\n  BaudRate = 19200 \n  StopBits = 1 \n  Parity   = none\r\n");

    tcflush (fd, TCIOFLUSH);
    return true;
}

void Close_UART (void)
{
    close(fd);/* Close the Serial port */
}

uint8_t  toHex (uint8_t   ch)
{
    uint8_t  ret_val;

    if ((ch >= '0') && (ch <= '9'))
        ret_val = ch - '0';
    else     if ((ch >= 'a') && (ch <= 'f'))
        ret_val = ch - 'a' + 10;
    else     if ((ch >= 'A') && (ch <= 'F'))
        ret_val = ch - 'A' + 10;
    else
        ret_val = 0xff;

    return ret_val;
}


void  Send_Command_UART (uint8_t  command[], uint8_t  length)
{
    int  bytes_written  = 0;  	/* Value for storing the number of bytes written to the port */ 
    uint32_t   j;
    uint8_t   string[1];
    struct termios SerialPortSettings;	/* Create the structure                          */

    string[0] = 0x55;
    tcgetattr (fd, &SerialPortSettings);	/* Get the current attributes of the Serial port */
    SerialPortSettings.c_cc[VMIN] = 1;
    tcsetattr(fd,TCSANOW,&SerialPortSettings);

    bytes_written = write (fd, string, 1);


//    printf ("Msg out: ");
//    for (uint8_t i=0; i <= length; i++)
//        printf (" %x", command[i]);
//    printf ("\r\n");
//    for (uint16_t i = 0; i < 10000; i++)
//        j = i+j ;

    tcgetattr (fd, &SerialPortSettings);	/* Get the current attributes of the Serial port */
    SerialPortSettings.c_cc[VMIN] = length;
    tcsetattr(fd,TCSANOW,&SerialPortSettings);

    bytes_written = write (fd, command, length);
}

void  Get_Response_UART (uint8_t  command[], uint8_t  length)
{
    int  bytes_read = 0;    /* Number of bytes read by the read() system call */
    uint8_t   cp;

    struct termios SerialPortSettings;	/* Create the structure                          */

    tcgetattr (fd, &SerialPortSettings);	/* Get the current attributes of the Serial port */
    SerialPortSettings.c_cc[VMIN] = length+1;
    tcsetattr(fd,TCSANOW,&SerialPortSettings);
 
    bytes_read = read(fd, command, length+1); /* Read the data                   */
//    printf ("Bytes Read: %d\r\n", bytes_read);
//    printf ("Get Version Response: ");
//    for (uint8_t i=0; i <= bytes_read; i++)
//        printf (" %x", command[i]);
//    printf ("\r\n");

    for (cp = 1; cp <= bytes_read; cp++)
        command[cp-1] = command [cp];
    command [length] = 0x23;       
}
