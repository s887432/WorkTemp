/* ***************************************************************************
 * ©2019 Microchip Technology Inc. and its subsidiaries.
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip   products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.
 * TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
 * CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES,
 * IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 */

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include "definitions.h"
#include "host_utils_uart.h"

void Init_PIC18_memory(uint16_t  flash_size, PIC18_memory_t  *PIC18)
{
    uint32_t  address;

    PIC18->flash_size = flash_size;
    for (address = 0; address < PIC18->flash_size; address++)
    {
        PIC18->Flash_Panel[address] = 0xFF;
    }

    for (address = 0; address < 1024; address++)
    {
        PIC18->EEData[address] = 0xFF;
    }
    for (address = 0; address < 8; address++)
    {
        PIC18->ID_Locs[address] = 0xFF;
    }
    for (address = 0; address < 16; address++)
    {
        PIC18->Config_Words[address] = 0xFF;
    }
}


uint16_t  Calc_Checksum_PIC18 (uint32_t  app_offset, PIC18_memory_t *PIC18)
{
    uint16_t  checksum = 0;
    printf ("Calculating Checksum:");
    for (uint16_t  i = app_offset; i < PIC18->flash_size; i+=2)
    {
        checksum += PIC18->Flash_Panel [i];
        checksum += ((uint16_t)PIC18->Flash_Panel [i+1]) << 8;
        if (i == (i & 0xFC00))
        putchar('.');
    }
    printf ("\r\n");
    return checksum;
}

void parse_PIC18_hex_file (FILE *fp, PIC18_memory_t *PIC18)
{
    uint8_t   hexline [120];
    bool      running= true;
    uint8_t   length;
    uint32_t  address;
    uint32_t  ext_address = 0;
    uint8_t   Record_type;
    uint8_t   hex_byte;
    uint16_t  Instruction;
    uint16_t  FP_Address;

    while (running)
    {
        fscanf (fp, "%s", hexline);	

        length = (toHex (hexline[1])) << 4;
        length += toHex (hexline[2]);

        address = ext_address;

        address += ((uint32_t)toHex (hexline[3])) << 12;
        address += ((uint32_t)toHex (hexline[4])) << 8;
        address += ((uint32_t)toHex (hexline[5])) << 4;
        address +=  (uint32_t)toHex (hexline[6]);
	Record_type = (toHex (hexline[7]) << 4) + (toHex (hexline[8]));

//        printf ("Length: %d  ", length);
//        printf ("Address: %x  ", address);
//        printf ("Record Type: %d\r\n", Record_type);

        switch (Record_type)
        {
        case 0:
            if (address < 0x200000)
            {
                for (uint8_t i = 0;i < length; i++)
                {
                    hex_byte = (toHex (hexline[9+2*i]) << 4) + toHex(hexline[10+2*i]); 
                    PIC18->Flash_Panel [address + i] = hex_byte;
                }

//                if (first_time)
//                {  // Save the first instruction and write it last
//                    Save_Address = address;
//                    first_instruction_lb = bl_command [9]; 
//                    first_instruction_hb = bl_command [10];
//                    hexline[9]  = 0xFF;
//                    hexline[10] = 0xFF;
//                    first_time = false;
//                }

//                printf ("Command Line: ");
//                for (uint8_t i = 0; i < 9+length; i++)
//                    printf (" %2x", bl_command [i]);
//                printf ("\r\n");

            }
            else if ((address >= 0x200000) && (address < 0x20000F))
            {
                for (uint8_t i = 0;i < length; i++)
                {
                    hex_byte = (toHex (hexline[9+2*i]) << 4) + toHex(hexline[10+2*i]); 
                    PIC18->ID_Locs [address - 0x200000 + i] = hex_byte;
                }
//                printf ("ID Locs: ");
//                for (uint8_t i = 0;i < 8; i++)
//                {
//                    printf ("%02x  ", PIC18->ID_Locs [address - 0x200000 + i]);
//                }
//                printf ("\r\n");
            }
            else if ((address >= 0x300000) && (address < 0x30000F))
            {
                for (uint8_t i = 0;i < length; i++)
                {
                    hex_byte = (toHex (hexline[9+2*i]) << 4) + toHex(hexline[10+2*i]); 
                    PIC18->Config_Words [address - 0x300000 + i] = hex_byte;
                }
            }
            else if ((address >= 0xf00000) && (address < 0xf00fff))
            {
                for (uint8_t i = 0;i < length; i++)
                {
                    hex_byte = (toHex (hexline[9+2*i]) << 4) + toHex(hexline[10+2*i]); 
                    PIC18->EEData [address - 0xf00000 + i] = hex_byte;
                }
            }
            break;

        case 1:


            running = false;

            break;

        case 2:
            printf ("Segment Record (record type 02) not supported \r\n");
            break;

        case 4:
            ext_address  = ((uint32_t)toHex (hexline[9])) << 28;
            ext_address += ((uint32_t)toHex (hexline[10])) << 24;
            ext_address += ((uint32_t)toHex (hexline[11])) << 20;
            ext_address += ((uint32_t)toHex (hexline[12])) << 16;
            break;
        }
    }
            
}

void PIC18_Memory_Dump (PIC18_memory_t  *PIC18)
{
    printf ("Flash Panel:  %x\r\n", PIC18->flash_size);
    for (uint16_t row = 0; row < PIC18->flash_size; row += 16)
    {
        printf ("%04x", row);
        for (uint16_t  col = 0; col < 16; col++)
            printf ("  %02x", PIC18->Flash_Panel[row+col]);
        printf ("\r\n");
    }

    printf ("EE Data:\r\n");
    for (uint16_t row = 0; row < 256; row += 16)
    {
        printf ("%04x", row);
        for (uint16_t  col = 0; col < 16; col++)
            printf ("  %02x", PIC18->EEData[row+col]);
        printf ("\r\n");
    }

    printf ("ID Locs: ");
        for (uint16_t  col = 0; col < 8; col++)
            printf ("  %02x", PIC18->ID_Locs[col]);
        printf ("\r\n");

    printf ("Conf Words: ");
        for (uint16_t  col = 0; col < 16; col++)
            printf ("  %02x", PIC18->ID_Locs[col]);
        printf ("\r\n");
}
