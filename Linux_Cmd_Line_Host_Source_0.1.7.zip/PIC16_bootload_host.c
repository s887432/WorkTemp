/* ***************************************************************************
 * ©2019 Microchip Technology Inc. and its subsidiaries.
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip   products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.
 * TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
 * CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES,
 * IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 */


#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include "definitions.h"
#include "host_utils_uart.h"
#include "host_utils_i2c.h"
#include "PIC16_hex_utils.h"


bool (*Open_Dev)(uint8_t  filepath[]);
void (*Send_Command)(uint8_t command[], uint8_t  length);
void (*Get_Response)(uint8_t command[], uint8_t  length);
void (*Close_Dev)(void);



void Erase_Flash (uint8_t  erase_row_size, uint32_t App_Offset, uint32_t  flash_size)
{
    uint8_t   bl_command[128];
    uint16_t  erase_length;

    printf ("Erase PFM  %x to %x   ", App_Offset, flash_size);
    if (erase_row_size != 0)
        erase_length = (flash_size-App_Offset)/erase_row_size;
    else
    {
        printf ("invalid erase row size.  Fix it in the bootloader get version command\n\r");
        return;
    }
    bl_command [0] = ERASE_FLASH;
    bl_command [1] = (uint8_t)  (erase_length & 0xFF);
    bl_command [2] = (uint8_t) ((erase_length & 0xFF00) >> 8);
    bl_command [3] = 0x55;
    bl_command [4] = 0xaa;
    bl_command [5] = (uint8_t)  (App_Offset & 0xFF);
    bl_command [6] = (uint8_t) ((App_Offset & 0xFF00) >> 8);
    bl_command [7] = (uint8_t) ((App_Offset & 0xFF0000) >> 16);
    bl_command [8] = (uint8_t) ((App_Offset & 0xFF000000) >> 24);

//    printf ("Erase Address: %x\r\n", App_Offset);
    Send_Command (bl_command, 9);
    Get_Response (bl_command, 10);

    if (bl_command[9] == 0x01)
         printf ("Success\r\n");
    else if (bl_command[9] == 0xFF)
         printf ("Failed Command Not Supported\r\n");
    else if (bl_command[9] == 0xFE)
         printf ("Failed Address error\r\n");
//    printf ("Erase response: 
//    for (uint8_t i = 0; i < 10; i++)
//        printf ("  %x",  bl_command[i]);
//    printf ("\r\n");
    
}

void Write_Flash (PIC16_memory_t  *PIC16, uint16_t write_latches, uint16_t  App_Offset)
{
    uint8_t   bl_command[128];
    bool      all_blank;
    uint16_t   address;

    printf ("Write Program Flash Memory\r\n");

    for (address = App_Offset; address < PIC16->flash_size; address += write_latches)
    {
        all_blank = true;
//       Build normal command line
        bl_command [0] = WRITE_FLASH;
        bl_command [1] = (2*write_latches) & 0xFF;
        bl_command [2] = ((2*write_latches) & 0xFF00)>>8;
        bl_command [3] = 0x55;
        bl_command [4] = 0xaa;
        bl_command [5] = (uint8_t)  (address & 0xFF);
        bl_command [6] = (uint8_t) ((address & 0xFF00) >> 8);
        bl_command [7] = (uint8_t) ((address & 0xFF0000) >> 16);
        bl_command [8] = (uint8_t) ((address & 0xFF000000) >> 24);

        for (uint8_t  i = 0; i < write_latches; i++)
        {
            if (PIC16->Flash_Panel[address+i] != 0x3FFF)
                all_blank = false;
            bl_command [2*i+9] = (uint8_t)(PIC16->Flash_Panel[address+i] & 0xFF); 
            bl_command [2*i+10] = (uint8_t)((PIC16->Flash_Panel[address+i] & 0xFF00) >> 8); 
        }
            
//        printf ("Command Line: ");
//        for (uint8_t i = 0; i < 9+2*write_latches; i++)
//            printf (" %2x", bl_command [i]);
//        printf ("\r\n");


        if (all_blank == true)
        {
//            printf ("Blank line suppressed\r\n");
        }
        else
        {
            Send_Command (bl_command, 9+2*write_latches);
            Get_Response (bl_command, 10);
        }

    }
}

#define LINE_LENGTH  0x20 
void Write_EEData (PIC16_memory_t *PIC16, uint16_t  length)
{
    uint8_t  bl_command [120];
    uint16_t  Instruction;
    uint16_t   address;

    printf ("Write EEData\r\n");

    for (address = 0; address < length; address += LINE_LENGTH)
    {
        bl_command [0] = WRITE_EE;
        bl_command [1] = (uint8_t)  (LINE_LENGTH & 0xFF);
        bl_command [2] = (uint8_t) ((LINE_LENGTH & 0xFF00)>>8);
        bl_command [3] = 0x55;
        bl_command [4] = 0xaa;
        bl_command [5] = (uint8_t)  (address & 0xFF);
        bl_command [6] = (uint8_t) ((address & 0xFF00) >> 8);
        bl_command [7] = (uint8_t) ((address & 0xFF0000) >> 16);
        bl_command [8] = (uint8_t) ((address & 0xFF000000) >> 24);

        for (uint8_t  i = 0; i < LINE_LENGTH; i++)
             bl_command [i+9] = PIC16->EEData[address+i]; 

//        printf ("Command Line: ");
//        for (uint8_t i = 0; i < 9+LINE_LENGTH; i++)
//            printf (" %02x", bl_command [i]);
//        printf ("\r\n");

        Send_Command (bl_command, 9+LINE_LENGTH);
        Get_Response (bl_command, 10);
    }
}

void Write_IDLocs (PIC16_memory_t  *PIC16)
{
    printf ("Write ID Locs\r\n");
    uint8_t   bl_command[128];
    uint16_t   address;

         address = 0x8000;
//       Build normal command line
        bl_command [0] = WRITE_CONFIG;
        bl_command [1] = 2*4;   // 9 byte header + 4 words
        bl_command [2] = 0;
        bl_command [3] = 0x55;
        bl_command [4] = 0xaa;
        bl_command [5] = (uint8_t)  (address & 0xFF);
        bl_command [6] = (uint8_t) ((address & 0xFF00) >> 8);
        bl_command [7] = (uint8_t) ((address & 0xFF0000) >> 16);
        bl_command [8] = (uint8_t) ((address & 0xFF000000) >> 24);

        for (uint8_t  i = 0; i < 4; i++)
        {
            bl_command [2*i+9]  = (uint8_t) (PIC16->ID_Locs[(address - 0x8000)+i] & 0xFF); 
            bl_command [2*i+10] = (uint8_t)((PIC16->ID_Locs[(address - 0x8000)+i] & 0xFF00) >> 8); 
        }
  
//        printf ("Command Line: ");
//        for (uint8_t i = 0; i < 9+2*4; i++)
//            printf (" %2x", bl_command [i]);
//        printf ("\r\n");


         Send_Command (bl_command, 9+2*4);
         Get_Response (bl_command, 10);

// *******************************************************************
//  test code to verify read ID locs functionality
//         bl_command [0] = READ_CONFIG;
//         printf ("Command Line: ");
//         for (uint8_t i = 0; i < 9; i++)
//             printf (" %2x", bl_command [i]);
//         printf ("\r\n");

//         Send_Command (bl_command, 9);
//         Get_Response (bl_command, 9+2*4);
//         printf ("Read ID Locs: ");
//         for (uint8_t i = 0; i < 9+2*4; i++)
//             printf (" %2x", bl_command [i]);
//         printf ("\r\n");
}

void Get_Device_ID_PIC16 ()
{
    uint8_t   bl_command[128];
    uint16_t   address;

    address = 0x8006;
//       Build normal command line
    bl_command [0] = READ_CONFIG;
    bl_command [1] = 2;   // 9 byte header + 1 words
    bl_command [2] = 0;
    bl_command [3] = 0x55;
    bl_command [4] = 0xaa;
    bl_command [5] = (uint8_t)  (address & 0xFF);
    bl_command [6] = (uint8_t) ((address & 0xFF00) >> 8);
    bl_command [7] = (uint8_t) ((address & 0xFF0000) >> 16);
    bl_command [8] = (uint8_t) ((address & 0xFF000000) >> 24);

    Send_Command (bl_command, 9);
    Get_Response (bl_command, 11);

    printf ("Device ID: %x%x\r\n", bl_command[10], bl_command[9]);
}

void Write_Config_Words (PIC16_memory_t  *PIC16)
{
    printf ("Write Config Words\r\n");
    uint8_t   bl_command[128];
    uint16_t   address;

    address = 0x8007;
//       Build normal command line
    bl_command [0] = WRITE_CONFIG;
    bl_command [1] = 2 * 5;  // 9 byte header + 5 words
    bl_command [2] = 0;
    bl_command [3] = 0x55;
    bl_command [4] = 0xaa;
    bl_command [5] = (uint8_t)  (address & 0xFF);
    bl_command [6] = (uint8_t) ((address & 0xFF00) >> 8);
    bl_command [7] = (uint8_t) ((address & 0xFF0000) >> 16);
    bl_command [8] = (uint8_t) ((address & 0xFF000000) >> 24);

    for (uint8_t  i = 0; i < 5; i++)
    {
        bl_command [2*i+9]  = (uint8_t) (PIC16->Config_Words[(address - 0x8007) + i] & 0xFF); 
        bl_command [2*i+10] = (uint8_t)((PIC16->Config_Words[(address - 0x8007) + i] & 0xFF00) >> 8); 
    }
            
//        printf ("Command Line: ");
//        for (uint8_t i = 0; i < 9+2*5; i++)
//            printf (" %2x", bl_command [i]);
//        printf ("\r\n");


     Send_Command (bl_command, 9+2*5);
     Get_Response (bl_command, 10);

// *******************************************************
//  test code to verify read config words functionality
//         bl_command [0] = READ_CONFIG;
//         Send_Command (bl_command, 9);
//         Get_Response (bl_command, 9+2*5);
//         printf ("Read Config words: ");
//         for (uint8_t i = 0; i < 9+2*5; i++)
//             printf (" %2x", bl_command [i]);
//         printf ("\r\n");

}


uint16_t  Get_Checksum (uint32_t App_Offset, uint32_t flash_size)
{
    uint8_t   bl_command[128];  
    uint32_t  length;
    uint16_t  checksum;
    
    length = (flash_size - App_Offset)*2;
    bl_command [0] = CALC_CHECKSUM;
    bl_command [1] = (uint8_t)  (length & 0xFF);
    bl_command [2] = (uint8_t) ((length & 0xFF00) >> 8);
    bl_command [3] = (uint8_t) ((length & 0xFF0000) >> 16);
    bl_command [4] = (uint8_t) ((length & 0xFF000000) >> 24);
    bl_command [5] = (uint8_t)  (App_Offset & 0xFF);
    bl_command [6] = (uint8_t) ((App_Offset & 0xFF00) >> 8);
    bl_command [7] = (uint8_t) ((App_Offset & 0xFF0000) >> 16);
    bl_command [8] = (uint8_t) ((App_Offset & 0xFF000000) >> 24);

    Send_Command (bl_command, 9);
    Get_Response (bl_command, 11);

    checksum = bl_command[9];
    checksum += ((uint16_t) bl_command[10]) << 8;

    return (checksum);
}


void  Reset_Device (void)
{
    uint8_t   bl_command[128];  
    
    bl_command [0] = RESET_DEVICE;
    bl_command [1] = 0x00;
    bl_command [2] = 0x00;
    bl_command [3] = 0x00;
    bl_command [4] = 0x00;
    bl_command [5] = 0x00;
    bl_command [6] = 0x00;
    bl_command [7] = 0x00;
    bl_command [8] = 0x00;

    Send_Command (bl_command, 9);
    Get_Response (bl_command, 9);
}



void Program_Device (void)
{
}

uint8_t Program_PIC16 (char FilePath[], char DestPath[], uint32_t App_Offset, uint32_t flash_size)
{   
    FILE * fp;

    uint8_t   bl_command[128];
    uint32_t  erase_row_size;
    uint32_t  write_latches;
    uint16_t  checksum;
    uint16_t  DeviceCheckSum;
    bool      all_blank;
    uint32_t  address;
    PIC16_memory_t PIC16;

    Init_PIC16_memory(flash_size, &PIC16);

    if (strstr (DestPath, "i2c") != NULL)
    {
         printf ("Set pointers for I2C\r\n");
         Open_Dev     = &Open_I2C;
         Send_Command = &Send_Command_I2C;
         Get_Response = &Get_Response_I2C;
         Close_Dev    = &Close_I2C;
    }
    else
    {
         printf ("Set pointers for UART\r\n");
         Open_Dev     = &Open_UART;
         Send_Command = &Send_Command_UART;
         Get_Response = &Get_Response_UART;
         Close_Dev    = &Close_UART;
    }

    fp = fopen (FilePath, "r+");
    if (fp == NULL)
    {
        printf ("Hex file not found.  Check file name and path\r\n");
        return -1;
    }
    if (Open_Dev (DestPath) == false)
    {
        fclose (fp);
        return -1;
    }
    parse_hex_file (fp, &PIC16);
    checksum = Calc_Checksum_PIC16 (App_Offset, &PIC16);

//    Memory_Dump (&PIC16_memory);

    bl_command [0] = READ_VERSION;
    for (uint8_t i = 1; i <10; i++)
        bl_command[i] = 0;
    printf ("Sending Get Version Command ...\r\n");
    Send_Command (bl_command, 9);   
//    printf ("Sent\r\n");

    for (uint8_t i = 0; i < 25; i++)
        bl_command[i] = 0x23;

    Get_Response (bl_command, 25);
    printf ("Get Version Response: ");
    for (uint8_t i=0; i < 25; i++)
        printf (" %x", bl_command[i]);
    printf ("\r\n");

    Get_Device_ID_PIC16();
    erase_row_size = bl_command [19]; 
    write_latches  = bl_command [20]; 
    printf ("Erase Row size: %x\r\n", erase_row_size);

    Erase_Flash (erase_row_size, App_Offset, flash_size);
    Write_Flash (&PIC16, write_latches, App_Offset);
    Write_EEData (&PIC16, 256);
    Write_IDLocs (&PIC16);
    Write_Config_Words (&PIC16);
    
    printf ("Flash Panel Checksum: %x  ", checksum);
    DeviceCheckSum =  Get_Checksum (App_Offset, flash_size);
    printf ("Device Checksum: %x\r\n", DeviceCheckSum);
    
    if (checksum == Get_Checksum (App_Offset, flash_size))
    {
        printf ("Checksums match.  Resetting device\r\n");
        Reset_Device ();
    }
    else
    {
        printf ("Checksum failed\r\n");
    }

    fclose (fp);
    Close_Dev ();

}

