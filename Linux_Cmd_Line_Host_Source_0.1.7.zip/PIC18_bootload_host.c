/* ***************************************************************************
 * ©2019 Microchip Technology Inc. and its subsidiaries.
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip   products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.
 * TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
 * CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES,
 * IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 */


#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include "host_utils_uart.h"
#include "host_utils_i2c.h"
#include "definitions.h"
#include "PIC16_bootload_host.h"
#include "PIC18_hex_utils.h"
#include "PIC18_bootload_host.h"

bool (*Open_Dev)(uint8_t  filepath[]);
void (*Send_Command)(uint8_t command[], uint8_t  length);
void (*Get_Response)(uint8_t command[], uint8_t  length);
void (*Close_Dev)(void);


void Write_Flash_PIC18 (PIC18_memory_t  *PIC18, uint16_t write_latches, uint16_t  App_Offset)
{
    uint8_t   bl_command[128];
    bool      all_blank;
    uint16_t   address;


    for (address = App_Offset; address < PIC18->flash_size; address += write_latches)
    {
        all_blank = true;
//       Build normal command line
        bl_command [0] = WRITE_FLASH;
        bl_command [1] = (write_latches) & 0xFF;
        bl_command [2] = (write_latches & 0xFF00)>>8;
        bl_command [3] = 0x55;
        bl_command [4] = 0xaa;
        bl_command [5] = (uint8_t)  (address & 0xFF);
        bl_command [6] = (uint8_t) ((address & 0xFF00) >> 8);
        bl_command [7] = (uint8_t) ((address & 0xFF0000) >> 16);
        bl_command [8] = (uint8_t) ((address & 0xFF000000) >> 24);

        for (uint8_t  i = 0; i < write_latches; i++)
        {
            if (PIC18->Flash_Panel[address+i] != 0xFF)
                all_blank = false;
            bl_command [i+9] = PIC18->Flash_Panel[address+i]; 
        }
            
//        printf ("Command Line: ");
//        for (uint8_t i = 0; i < 9+2*write_latches; i++)
//            printf (" %2x", bl_command [i]);
//        printf ("\r\n");


        if (all_blank == true)
        {
//            printf ("Blank line suppressed\r\n");
        }
        else
        {
            Send_Command (bl_command, 9+write_latches);
            Get_Response (bl_command, 10);
        }

    }
}

void Write_EEData_PIC18 (PIC18_memory_t  *PIC18, uint16_t  length)
{
    uint8_t  bl_command [120];
    uint16_t  Instruction;

    printf ("Write EE Data\r\n");
    for (uint16_t  EE_Address = 0; EE_Address < length; EE_Address+=32)     
    {
        bl_command [0] = WRITE_EE;
        bl_command [1] = 32;
        bl_command [2] = 0;
        bl_command [3] = 0x55;
        bl_command [4] = 0xaa;
        bl_command [5] = (uint8_t)  (EE_Address & 0xFF);
        bl_command [6] = (uint8_t) ((EE_Address & 0xFF00) >> 8);
        bl_command [7] = (uint8_t) ((EE_Address & 0xFF0000) >> 16);
        bl_command [8] = (uint8_t) ((EE_Address & 0xFF000000) >> 24);

        for (uint8_t  i = 0; i < 32; i++)
            bl_command [i+9] = PIC18->EEData[EE_Address+i]; 
            
//        printf ("Command Line: ");
//        for (uint8_t i = 0; i < 9+32; i++)
//            printf (" %2x", bl_command [i]);
//        printf ("\r\n");

        Send_Command (bl_command, 9+32);
        Get_Response (bl_command, 10);
    }
}
void Read_EEData_PIC18 (PIC18_memory_t  *PIC18, uint16_t  length)
{
    uint8_t  bl_command [120];
    uint16_t  Instruction;

    printf ("Read EE Data\r\n");
    for (uint16_t  EE_Address = 0; EE_Address < length; EE_Address+=32)     
    {
        bl_command [0] = READ_EE;
        bl_command [1] = 32;
        bl_command [2] = 0;
        bl_command [3] = 0;
        bl_command [4] = 0;
        bl_command [5] = (uint8_t)  (EE_Address & 0xFF);
        bl_command [6] = (uint8_t) ((EE_Address & 0xFF00) >> 8);
        bl_command [7] = (uint8_t) ((EE_Address & 0xFF0000) >> 16);
        bl_command [8] = (uint8_t) ((EE_Address & 0xFF000000) >> 24);

        Send_Command (bl_command, 9);
        Get_Response (bl_command, 9+32);

//        printf ("Command Line: ");
//        for (uint8_t i = 0; i < 9+32; i++)
//            printf (" %2x", bl_command [i]);
//        printf ("\r\n");
    }
}

void Write_IDLocs_PIC18 (PIC18_memory_t  *PIC18)
{
    printf ("Write ID Locs\r\n");
    uint8_t   bl_command[128];
    uint32_t   address;

         address = 0x200000;
//       Build normal command line
        bl_command [0] = WRITE_CONFIG;
        bl_command [1] = 2*4;   // 9 byte header + 4 words
        bl_command [2] = 0;
        bl_command [3] = 0x55;
        bl_command [4] = 0xaa;
        bl_command [5] = (uint8_t)  (address & 0xFF);
        bl_command [6] = (uint8_t) ((address & 0xFF00) >> 8);
        bl_command [7] = (uint8_t) ((address & 0xFF0000) >> 16);
        bl_command [8] = (uint8_t) ((address & 0xFF000000) >> 24);

        for (uint8_t  i = 0; i < 8; i++)
        {
            bl_command [i+9]  = (uint8_t) (PIC18->ID_Locs[i] & 0xFF); 
        }
   
//        printf ("Command Line: ");
//        for (uint8_t i = 0; i < 9+8; i++)
//            printf (" %2x", bl_command [i]);
//         printf ("\r\n");
        Send_Command (bl_command, 9+8);
        Get_Response (bl_command, 10);



// ***********************************************************
// Read ID Locs test code
//        bl_command [0] = READ_CONFIG;
//        Send_Command (bl_command, 9);
//        Get_Response (bl_command, 9+8);
//        printf ("Read ID Locs: ");
//        for (uint8_t i = 0; i < 9+8; i++)
//            printf (" %2x", bl_command [i]);
//         printf ("\r\n");

}
void Get_Device_ID_PIC18 ()
{
    printf ("Write ID Locs\r\n");
    uint8_t   bl_command[128];
    uint32_t   address;

     address = 0x3FFFFE;    //       Build normal command line
    bl_command [0] = READ_CONFIG;
    bl_command [1] = 2;   // 9 byte header + 4 words
    bl_command [2] = 0;
    bl_command [3] = 0x0;
    bl_command [4] = 0x0;
    bl_command [5] = (uint8_t)  (address & 0xFF);
    bl_command [6] = (uint8_t) ((address & 0xFF00) >> 8);
    bl_command [7] = (uint8_t) ((address & 0xFF0000) >> 16);
    bl_command [8] = (uint8_t) ((address & 0xFF000000) >> 24);
 
//        printf ("Command Line: ");
//        for (uint8_t i = 0; i < 9+8; i++)
//            printf (" %2x", bl_command [i]);
//         printf ("\r\n");
    Send_Command (bl_command, 9);
    Get_Response (bl_command, 11);

    printf ("Device ID: %x%x\r\n", bl_command [10], bl_command[11]);


// ***********************************************************
// Read ID Locs test code
//        bl_command [0] = READ_CONFIG;
//        Send_Command (bl_command, 9);
//        Get_Response (bl_command, 9+8);
//        printf ("Read ID Locs: ");
//        for (uint8_t i = 0; i < 9+8; i++)
//            printf (" %2x", bl_command [i]);
//         printf ("\r\n");

}

void Write_Config_Words_PIC18 (PIC18_memory_t  *PIC18)
{
    printf ("Write Config Words\r\n");
    uint8_t   bl_command[128];
    uint32_t   address;

    address = 0x300000;
//       Build normal command line
    bl_command [0] = WRITE_CONFIG;
    bl_command [1] = 14;  
    bl_command [2] = 0;
    bl_command [3] = 0x55;
    bl_command [4] = 0xaa;
    bl_command [5] = (uint8_t)  (address & 0xFF);
    bl_command [6] = (uint8_t) ((address & 0xFF00) >> 8);
    bl_command [7] = (uint8_t) ((address & 0xFF0000) >> 16);
    bl_command [8] = (uint8_t) ((address & 0xFF000000) >> 24);

    for (uint8_t  i = 0; i < 14; i++)
    {
        bl_command [i+9]  = (uint8_t) (PIC18->Config_Words[i] & 0xFF); 
    }

//        printf ("Command Line: ");
//        for (uint8_t i = 0; i < 9+14; i++)
//            printf (" %2x", bl_command [i]);
//        printf ("\r\n");


     Send_Command (bl_command, 9+14);
     Get_Response (bl_command, 10);

// ***********************************************************
// Read Conf words test code
//        bl_command [0] = READ_CONFIG;
//        Send_Command (bl_command, 9);
//        Get_Response (bl_command, 9+14);
//        printf ("Read Config Words: ");
//        for (uint8_t i = 0; i < 9+14; i++)
//            printf (" %2x", bl_command [i]);
//         printf ("\r\n");

}


uint16_t  PIC18F_Get_Checksum (uint32_t App_Offset, uint32_t flash_size)
{
    uint8_t   bl_command[128];  
    uint32_t  length;
    uint16_t  checksum;
    
    length = (flash_size - App_Offset);
    bl_command [0] = CALC_CHECKSUM;
    bl_command [1] = (uint8_t)  (length & 0xFF);
    bl_command [2] = (uint8_t) ((length & 0xFF00) >> 8);
    bl_command [3] = (uint8_t) ((length & 0xFF0000) >> 16);
    bl_command [4] = (uint8_t) ((length & 0xFF000000) >> 24);
    bl_command [5] = (uint8_t)  (App_Offset & 0xFF);
    bl_command [6] = (uint8_t) ((App_Offset & 0xFF00) >> 8);
    bl_command [7] = (uint8_t) ((App_Offset & 0xFF0000) >> 16);
    bl_command [8] = (uint8_t) ((App_Offset & 0xFF000000) >> 24);

    Send_Command (bl_command, 9);
    Get_Response (bl_command, 11);

    checksum = bl_command[9];
    checksum += ((uint16_t) bl_command[10]) << 8;

    return (checksum);
}




//                bl_command [0] = WRITE_FLASH;
//                bl_command [1] = length & 0xFF;
//                bl_command [2] = (length & 0xFF00)>>8;
//                bl_command [3] = 0x55;
//                bl_command [4] = 0xaa;
 //               bl_command [5] = (uint8_t)  (address & 0xFF);
//                bl_command [6] = (uint8_t) ((address & 0xFF00) >> 8);
//                bl_command [7] = (uint8_t) ((address & 0xFF0000) >> 16);
//                bl_command [8] = (uint8_t) ((address & 0xFF000000) >> 24);

//                if (all_blank == true)
//                {
//                    printf ("Blank line suppressed\r\n");
//                }
//                else
//                {
//                    Send_Command (bl_command, 9+length);
//                    Get_Response (bl_command, 10);
//                }


uint8_t Program_PIC18 (char FilePath[], char DestPath[], uint32_t App_Offset, uint32_t flash_size)
{   
    FILE * fp;

    uint8_t   bl_command[128];
    uint32_t  erase_row_size;
    uint32_t  write_latches;
    uint16_t  checksum;
    uint16_t  DeviceCheckSum;
    PIC18_memory_t    PIC18;


    if (strstr (DestPath, "i2c") != NULL)
    {
         printf ("Set pointers for I2C\r\n");
         Open_Dev     = &Open_I2C;
         Send_Command = &Send_Command_I2C;
         Get_Response = &Get_Response_I2C;
         Close_Dev    = &Close_I2C;
    }
    else
    {
         printf ("Set pointers for UART\r\n");
         Open_Dev     = &Open_UART;
         Send_Command = &Send_Command_UART;
         Get_Response = &Get_Response_UART;
         Close_Dev    = &Close_UART;
    }

    fp = fopen (FilePath, "r+");
    if (fp == NULL)
    {
        printf ("Hex file not found.  Check file name and path\r\n");
        return -1;
    }
    if (Open_Dev (DestPath) == false)
    {
        printf ("Open failed?\r\n");
        fclose (fp);
        return -1;
    }
    Init_PIC18_memory(flash_size, &PIC18);
    parse_PIC18_hex_file (fp, &PIC18);
//    PIC18_Memory_Dump(&PIC18);
    checksum = Calc_Checksum_PIC18 (App_Offset, &PIC18);

    bl_command [0] = READ_VERSION;
    for (uint8_t i = 1; i <10; i++)
        bl_command[i] = 0;
    printf ("Sending Get Version Command ...\r\n");
    Send_Command (bl_command, 9);   

    for (uint8_t i = 0; i < 25; i++)
        bl_command[i] = 0x23;

    Get_Response (bl_command, 25);
    printf ("Get Version Response: ");
    for (uint8_t i=0; i < 25; i++)
        printf (" %x", bl_command[i]);
    printf ("\r\n");
    erase_row_size = bl_command [19]; 
    write_latches  = bl_command [20]; 
    
    printf ("Erase Row size: %x    write latches: %x\r\n", erase_row_size, write_latches);
    Get_Device_ID_PIC18 ();
    Erase_Flash (erase_row_size, App_Offset, flash_size);
    Write_Flash_PIC18 (&PIC18, write_latches, App_Offset);
    Write_EEData_PIC18 (&PIC18, 256);
    Read_EEData_PIC18 (&PIC18, 256);
    Write_IDLocs_PIC18 (&PIC18);
    Write_Config_Words_PIC18 (&PIC18);

    printf ("Starting device checksum\r\n");
    DeviceCheckSum =  PIC18F_Get_Checksum (App_Offset, flash_size);
    printf ("Flash Panel checksum: %04x    Device Checksum: %04x\r\n", checksum, DeviceCheckSum);
    

    if (checksum == DeviceCheckSum)
    {
        printf ("Checksums match.  Resetting device\r\n");
        Reset_Device ();
    }
    else
    {
        printf ("Checksum failed\r\n");
    }

    fclose (fp);
    Close_Dev ();

}

