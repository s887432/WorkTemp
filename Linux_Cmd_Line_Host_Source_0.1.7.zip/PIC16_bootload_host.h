/* ***************************************************************************
 * ©2019 Microchip Technology Inc. and its subsidiaries.
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip   products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.
 * TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
 * CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES,
 * IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 */

uint8_t Program_PIC16 (char FilePath[], char DestPath[], uint32_t App_Offset, uint32_t flash_size);
void Erase_Flash (uint8_t  erase_row_size, uint32_t App_Offset, uint32_t  flash_size);
void Write_Flash (PIC16_memory_t  *PIC16, uint16_t write_latches, uint16_t  App_Offset);
void Write_EEData (PIC16_memory_t  *PIC16, uint8_t  length);
void Write_IDLocs (PIC16_memory_t  *PIC16);
void Write_Config_Words (PIC16_memory_t  *PIC16);
uint16_t  Get_Checksum (uint32_t App_Offset, uint32_t flash_size);
void  Reset_Device (void);

