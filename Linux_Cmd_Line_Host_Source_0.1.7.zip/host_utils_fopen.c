#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>   /* File Control Definitions           */
#include <termios.h> /* POSIX Terminal Control Definitions */
#include <unistd.h>  /* UNIX Standard Definitions 	   */ 
#include <errno.h>   /* ERROR Number Definitions           */

/*-------------------------------------------------------------*/
/* termios structure -  /usr/include/asm-generic/termbits.h    */ 
/* use "man termios" to get more info about  termios structure */
/*-------------------------------------------------------------*/

FILE * fd;/*File Descriptor*/

void UART_Open(void)
{


/*------------------------------- Opening the Serial Port -------------------------------*/
    fd = fopen ("/dev/ttyACM0", "rwb");
/* Change /dev/ttyUSB0 to the one corresponding to your system */

//    fd = open("/dev/ttyACM0", O_RDWR | O_NOCTTY  | O_NDELAY);	/* ttyUSB0 is the FT232 based USB2SERIAL Converter   */
//    fd = open("/dev/ttyACM0", O_RDWR | O_NOCTTY | O_DSYNC);	/* ttyUSB0 is the FT232 based USB2SERIAL Converter   */
		   						/* O_RDWR Read/Write access to serial port           */
								/* O_NOCTTY - No terminal will control the process   */
								/* O_NDELAY -Non Blocking Mode,Does not care about-  */
								/* -the status of DCD line,Open() returns immediatly */
									
    if (fd == NULL)						/* Error Checking */
        printf("\n  Error! in Opening ttyACM0  ");
    else
        printf("\n  ttyACM0 Opened Successfully ");

	
   /*---------- Setting the Attributes of the serial port using termios structure --------- */
		
    struct termios SerialPortSettings;	/* Create the structure                          */

    tcgetattr (fd, &SerialPortSettings);	/* Get the current attributes of the Serial port */

    cfsetispeed(&SerialPortSettings,B19200); /* Set Read  Speed as 19200                       */
    cfsetospeed(&SerialPortSettings,B19200); /* Set Write Speed as 19200                       */

    SerialPortSettings.c_cflag &= ~PARENB;   /* Disables the Parity Enable bit(PARENB),So No Parity   */
    SerialPortSettings.c_cflag &= ~CSTOPB;   /* CSTOPB = 2 Stop bits,here it is cleared so 1 Stop bit */
    SerialPortSettings.c_cflag &= ~CSIZE;    /* Clears the mask for setting the data size             */
    SerialPortSettings.c_cflag |=  CS8;      /* Set the data bits = 8                                 */
	
    SerialPortSettings.c_cflag &= ~CRTSCTS;       /* No Hardware flow Control                         */
    SerialPortSettings.c_cflag |= CREAD | CLOCAL; /* Enable receiver,Ignore Modem Control lines       */ 
		
		
    SerialPortSettings.c_iflag &= ~(IXON | IXOFF | IXANY);          /* Disable XON/XOFF flow control both i/p and o/p */
    SerialPortSettings.c_iflag &= ~(ICANON | ECHO | ECHOE | ISIG);  /* Non Cannonical mode                            */

    SerialPortSettings.c_oflag &= ~OPOST;/*No Output Processing*/

    if ((tcsetattr(fd,TCSANOW,&SerialPortSettings)) != 0) /* Set the attributes to the termios structure*/
        printf("\n  ERROR ! in Setting attributes");
    else
        printf("\n  BaudRate = 19200 \n  StopBits = 1 \n  Parity   = none\r\n");
}

void UART_Close (void)
{
    fclose(fd);/* Close the Serial port */
}

uint8_t  toHex (uint8_t   ch)
{
    uint8_t  ret_val;

    if (ch >= '0' && ch <= '9')
        ret_val = ch - '0';
    else     if (ch >= 'a' && ch <= 'f')
        ret_val = ch - 'a' + 10;
    else     if (ch >= 'A' && ch <= 'F')
        ret_val = ch - 'A' + 10;
    else
        ret_val = 0xff;

    return ret_val;
}


void  Send_Command (uint8_t  command[], uint8_t  length)
{
    uint8_t   cp;

    for (cp = length; cp > 0; cp--)
        command[cp] = command [cp-1];
    command [0] = 0x55;       
    int  bytes_written  = 0;  	/* Value for storing the number of bytes written to the port */ 

    printf ("Msg out: ");
    for (uint8_t i=0; i <= length; i++)
        printf (" %x", command[i]);
    printf ("\r\n");
    fwrite (command, 1, length, fd);
//    bytes_written = write (fd, command, length+1);
}

void  Get_Response (uint8_t  command[], uint8_t  length)
{
    int  bytes_read = 0;    /* Number of bytes read by the read() system call */
    uint8_t   cp;

 
//    bytes_read = fread(fd, command, length+1); /* Read the data                   */
    fread (command, 1, length, fd);
    printf ("Bytes Read: %d\r\n", bytes_read);
    printf ("Get Version Response: ");
    for (uint8_t i=0; i <= bytes_read; i++)
        printf (" %x", command[i]);
    printf ("\r\n");

    for (cp = 1; cp <= bytes_read; cp++)
        command[cp-1] = command [cp];
    command [length] = 0x23;       
}
