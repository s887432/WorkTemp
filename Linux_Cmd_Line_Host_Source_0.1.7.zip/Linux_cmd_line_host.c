/* ***************************************************************************
 * ©2019 Microchip Technology Inc. and its subsidiaries.
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip   products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.
 * TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
 * CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES,
 * IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 */

/* ****************************************************************************
 * Linux Command Line Bootloader host.
 *
 * Usage:  sudo ./cmd_line_host  <source hex file> <destination device> <Application offset> <Flash Memory Size> <family>\r\n\n");
 *
 * must run as SU as it's required to access /dev/*
 *
 * where
 *  * Destination device in my case is /dev/ttyACM0
 *  * Application Offset is the beginning address of the applicatioon.  Addresses 
 *    below that are reserved for the bootloader  
 *  * Flash Memory Size is the number of words flash memory for PIC16
 *  * family is either "pic16" or "pic18".
 *
 * Alternately you can add a rule /etc/udev/rules.d to change permissions on the port.
 * add a file (I called my file 50-myusb.rules)
 * SUBSYSTEMS=="usb", ATTRS{idVendor}=="04d8",ATTRS{idProduct}=="0057",GROUP="users", MODE="0666"
 * Replace with your vendor & product ID
 * lsusb -vvv    will let you find the device's Vendor & Product IDs.
 */
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include "definitions.h"
#include "PIC16_bootload_host.h"
#include "PIC18_bootload_host.h"


void main (int argc, char * argv[])
{
    uint32_t  offset;
    uint32_t  flash_size;

    printf ("Microchip Linux Command Line Bootload host Version %d.%d.%d\r\n\n", VERSION_MAJOR, VERSION_MINOR, VERSION_DOT);
    printf ("Source Hex File:     %s\r\n", argv[1]);
    printf ("Destination Device:  %s\r\n", argv[2]);
    printf ("Application Offset:  %s\r\n", argv[3]);
    printf ("Flash Memory Size:   %s\r\n", argv[4]);
    printf ("Device Family:       %s\r\n", argv[5]);

    if (argc == 1)
        printf ("Insufficient Command line parameters.  Usage:  ./cmd_line_host  <source hex file> <destination device> <bootload Offset>  <Flash Mem Size> <family>\r\n\n");
    else
    {
        for (int i = 1; i < argc; i++)
        {
            if (strcmp (argv[i], "-v") == 0)
            {
                printf ("cmd line host version %d.%d.%d\r\n", VERSION_MAJOR, VERSION_MINOR, VERSION_DOT);
            }
            if (strcmp (argv[i], "-h") == 0)
            {
                 printf ("cmd_line_host.\r\n Usage:  ./cmd_line_host  <source hex file> <destination device> <Bootload offset> <Flash Mem Size>  <Family>\r\n");
                 printf ("Options:\r\n  -h  help\r\n  -v  version\r\n");
            }
        }
    }
   
    sscanf (argv[3], "%x", &offset);
    sscanf (argv[4], "%x", &flash_size);
    if (strcmp(argv[5], "pic16") == 0)
    {
        Program_PIC16 (argv[1], argv[2], offset, flash_size);
    }
    else if (strcmp(argv[5], "pic18") == 0)
    {
        Program_PIC18 (argv[1], argv[2], offset, flash_size);
    }
    else if (strcmp(argv[5], "pic18_k42") == 0)
    {
        Program_PIC18 (argv[1], argv[2], offset, flash_size);
    }

    printf ("Done!\r\n");
}
