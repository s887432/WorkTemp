/* ***************************************************************************
 * ©2019 Microchip Technology Inc. and its subsidiaries.
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip   products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.
 * TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
 * CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES,
 * IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 */


#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include "definitions.h"
#include "host_utils_uart.h"


void Init_PIC16_memory(uint16_t  flash_size, PIC16_memory_t  *PIC16)
{
    PIC16->flash_size = flash_size;
    for (uint16_t address= 0; address < 0x8000; address++)
        PIC16->Flash_Panel[address] = 0x3FFF;
    for (uint16_t address= 0; address < 0x400; address++)
        PIC16->EEData [address] = 0xFF;
    for (uint16_t address= 0; address < 0x4; address++)
        PIC16->ID_Locs [address] = 0x3FFF;
    for (uint16_t address= 0; address < 0x16; address++)
        PIC16->Config_Words [address] = 0x3FFF;
}

uint16_t  Calc_Checksum_PIC16 (uint32_t  app_offset, PIC16_memory_t *PIC16_memory)
{
    uint16_t  checksum = 0;
    printf ("Calculating Checksum:");
    for (uint16_t  i = app_offset; i < PIC16_memory->flash_size; i++)
    {
        checksum += PIC16_memory->Flash_Panel [i];
        if (i == (i & 0xFF00))
        putchar('.');
    }
    printf ("\r\n");
    return checksum;
}

void parse_hex_file (FILE *fp, PIC16_memory_t *PIC16_memory)
{
    uint8_t hexline [120];
    bool    running= true;
    uint8_t  length;
    uint32_t  address;
    uint32_t  ext_address = 0;
    uint8_t   Record_type;
    uint16_t  FP_Address;
    uint16_t  Instruction;

    while (running)
    {
        fscanf (fp, "%s", hexline);	
//        printf ("%s\r\n", hexline);

        length = (toHex (hexline[1])) << 4;
        length += toHex (hexline[2]);
        address = ext_address;
        address += ((uint32_t)toHex (hexline[3])) << 12;
        address += ((uint32_t)toHex (hexline[4])) << 8;
        address += ((uint32_t)toHex (hexline[5])) << 4;
        address +=  (uint32_t)toHex (hexline[6]);
        address /=2;   // Convert from byte address to word address
	Record_type = (toHex (hexline[7]) << 4) + (toHex (hexline[8]));

//        printf ("Length: %d  ", length);
//        printf ("Address: %x  ", address);
//        printf ("Record Type: %d\r\n", Record_type);
        switch (Record_type)
        {
        case 0:
            if (address < 0x8000)
            {
                for (uint8_t i = 0;i < 2*length; i+= 4)
                {
                    Instruction = (toHex (hexline[11+i]) << 12)
                                + (toHex (hexline[12+i]) << 8) 
                                + (toHex (hexline[ 9+i]) << 4) 
                                +  toHex (hexline[10+i]);
                    PIC16_memory->Flash_Panel [address + i/4] = Instruction;
                }
            }
            else if ((address >= 0xf000) && (address < 0xffff))
            {
                printf ("loading EE Data\r\n");
                for (uint8_t i = 0; i < 2*length; i+= 4)
                {
                    PIC16_memory->EEData [(address & 0x3FF) + i/4] = (toHex (hexline[9+i]) << 4) + toHex(hexline[10+i]);
                }
            }
            else if ((address >= 0x8000) && (address < 0x8004))
            {
                printf ("loading ID_Locs\r\n");
                for (uint8_t i = 0; i < 2*length; i+= 4)
                {
                    PIC16_memory->ID_Locs[address - 0x8000 + i/4] = (toHex (hexline[11+i]) << 12)
                                                                 + (toHex (hexline[12+i]) << 8) 
                                                                 + (toHex (hexline[ 9+i]) << 4) 
                                                                 +  toHex (hexline[10+i]);
                }
            }
            else if ((address >= 0x8007)  && (address < 0x8010))
            {
                printf ("loading Config Words\r\n");
                for (uint8_t i = 0; i < 2*length; i+= 4)
                {
                    PIC16_memory->Config_Words [address - 0x8007 + i/4] = (toHex (hexline[11+i]) << 12)
                                                                        + (toHex (hexline[12+i]) << 8) 
                                                                        + (toHex (hexline[ 9+i]) << 4) 
                                                                        +  toHex (hexline[10+i]);
                }
            }
            break;

        case 1:
            running = false;
            break;

        case 2:
            printf ("Segment Record (record type 02) not supported \r\n");
            break;

        case 4:
            ext_address  = ((uint32_t)toHex (hexline[9])) << 28;
            ext_address += ((uint32_t)toHex (hexline[10])) << 24;
            ext_address += ((uint32_t)toHex (hexline[11])) << 20;
            ext_address += ((uint32_t)toHex (hexline[12])) << 16;
//            printf ("Segment Address:  %08x\r\n", ext_address);
            break;
        }
    }
            
//printf ("end program\r\n");
}



void Memory_Dump (PIC16_memory_t  *PIC16)
{
   printf ("Flash Memory Array:\r\n");
    for (uint16_t row = 0; row < PIC16->flash_size; row += 8)
    {
        printf ("%04x", row);
        for (uint16_t  col = 0; col < 8; col++)
            printf ("  %04x", PIC16->Flash_Panel[row+col]);
        printf ("\r\n");
    }
    printf ("\nEE Data\r\n");
    for (uint16_t row = 0; row < 256; row += 8)
    {
        printf ("%04x", row);
        for (uint16_t  col = 0; col < 8; col++)
            printf ("  %02x", PIC16->EEData[row+col]);
        printf ("\r\n");
    }
    printf ("\nID_Locs\r\n");
    printf ("%04x", 0x8000);
    for (uint16_t  col = 0; col < 4; col++)
        printf ("  %04x", PIC16->ID_Locs[col]);
    printf ("\r\n\nConfig Words\r\n");
    printf ("%04x", 0x8007);
    for (uint16_t  col = 0; col < 8; col++)
        printf ("  %04x", PIC16->Config_Words[col]);
    printf ("\r\n");
}

