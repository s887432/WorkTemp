Linux Command Line Host

Version 0.1.6 beta
Developed on Ubuntu 18.04 LTS
gcc v7.3.0
i2c port provided by a Microchip MCP2221 i2c-USB bridge.  

Usage:  ./cmd_line_host  <source hex file> <destination device> <Application offset> <Flash Memory size> <family> 

  where
   * Destination device in my case is /dev/ttyACM0
   * Application Offset is the beginning address of the application.  Addresses 
     below that are reserved for the bootloader  
   * Flash Memory Size is the number of words flash memory for PIC16, bytes for PIC18F.
   * family is "pic16", "pic18" ("pic18" includes pic18_k42 family).

Either the port permissions must allow access to the destination device, or the command can be run with sudo.

Here's how to set the device permissions
  Add a rule /etc/udev/rules.d to change permissions on the port.
  add a file (I called my file 50-myusb.rules) with this line:

  SUBSYSTEMS=="usb", ATTRS{idVendor}=="04d8",ATTRS{idProduct}=="0057",GROUP="users", MODE="0666"

  Replace with your vendor & product ID
  lsusb -vvv    will let you find the device's Vendor & Product IDs.

The MCP2221 readme.txt file gives good details on how to build and install the I2c drivers.

Known limitations:
1.  No support for EEDATA or configuration words


last updated 07May2019

