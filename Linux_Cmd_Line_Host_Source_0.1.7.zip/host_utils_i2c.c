/* ***************************************************************************
 * ©2019 Microchip Technology Inc. and its subsidiaries.
 *
 * Subject to your compliance with these terms, you may use Microchip software
 * and any derivatives exclusively with Microchip   products. It is your
 * responsibility to comply with third party license terms applicable to your
 * use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT,
 * SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE
 * OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.
 * TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
 * CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES,
 * IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 */

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>   /* File Control Definitions           */
//#include <iic.h>
#include <unistd.h>  /* UNIX Standard Definitions 	   */ 
#include <errno.h>   /* ERROR Number Definitions           */
#include <linux/i2c-dev.h>
#include <sys/ioctl.h>
//#include <i2c/smbus.h>

#define  I2C_ADDRESS   0x12
/*-------------------------------------------------------------*/
/* termios structure -  /usr/include/asm-generic/termbits.h    */ 
/* use "man termios" to get more info about  termios structure */
/*-------------------------------------------------------------*/

int fd;/*File Descriptor*/

bool Open_I2C(uint8_t  filepath[])
{


/*------------------------------- Opening the I2C Port -------------------------------*/

/* Change /dev/ttyUSB0 to the one corresponding to your system */

    fd = open(filepath, O_RDWR/* | O_NOCTTY | O_DSYNC*/);	/* ttyUSB0 is the FT232 based USB2SERIAL Converter   */
		   						/* O_RDWR Read/Write access to serial port           */
								/* O_NOCTTY - No terminal will control the process   */
								/* O_NDELAY -Non Blocking Mode,Does not care about-  */
								/* -the status of DCD line,Open() returns immediatly */
									
    if (fd == -1)						/* Error Checking */
    {
        printf("Error! in Opening %s \n", filepath);
        return false;
    }
    else
        printf("%s Opened Successfully \n", filepath);

    if (ioctl (fd, I2C_SLAVE, I2C_ADDRESS) < 0)
        printf ("Set I2C slave address failed.\r\n");
    else
        printf ("Set I2C Slave address successful.\r\n");


    return true;
}

void Close_I2C (void)
{
    close(fd);/* Close the i2c port */
}



void  Send_Command_I2C (uint8_t  command[], uint8_t  length)
{
    int  bytes_written  = 0;  	/* Value for storing the number of bytes written to the port */ 

    bytes_written = write (fd, command, length);
}

void  Get_Response_I2C (uint8_t  command[], uint8_t  length)
{
    int  bytes_read = 0;    /* Number of bytes read by the read() system call */     
    uint8_t  retries = 20;
    
    while ((bytes_read <= 0)
        && (retries    >  0))
    {
        bytes_read = read(fd, command, length); /* Read the data                   */
        printf ("i2c Get Response.  Bytes read %d    retries: %d\r\n", bytes_read, retries);
        -- retries;
    }

    for (uint8_t  i = 0; i < bytes_read; i++)
        printf ("%02x ", command[i]);
    printf ("\r\n");
}

void main_test_function()
{
    uint8_t   command [64];
    uint8_t   bytes_written;

    Open_I2C ("/dev/i2c-15");
    for (uint8_t i = 0; i < 9; i++)
       command [i] = i;

    printf ("about to send command: %x\r\n", command[0]);
    Send_Command_I2C (command, 9);

    printf ("about to read response:\r\n");
    Get_Response_I2C (command, 25);

    printf ("Done!\r\n");
    Close_I2C();
}
